function postComment() {
  const textarea = document.querySelector("textarea");
  const comments = document.getElementById("comments");
  if (textarea.value.trim() !== "") {
    const comment = document.createElement("p");
    comment.textContent = textarea.value;
    comments.appendChild(comment);
    textarea.value = "";
  }
}